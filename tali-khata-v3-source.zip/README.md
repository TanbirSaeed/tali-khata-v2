# Tali Khata V3

বাংলা ভাষাভিত্তিক ছোট ব্যবসার হিসাব রাখার Android-friendly অ্যাপ।

## বর্তমান ফিচার
- Dashboard: আয়, খরচ, বাকি ও কাস্টমারের সারাংশ
- কাস্টমার যোগ/খোঁজা/মুছে ফেলা
- বাকি, বাকি আদায়, আয় ও খরচের লেনদেন
- JSON ব্যাকআপ ডাউনলোড
- মোবাইল-ফ্রেন্ডলি UI

## গুরুত্বপূর্ণ ডেটা নোট
এই প্রাথমিক সংস্করণে ডেটা ব্রাউজার/ডিভাইসের `localStorage`-এ থাকে। এটি এখনো Cloud Sync নয়। অ্যাপের ডেটা মুছে গেলে হারাতে পারে, তাই নিয়মিত JSON ব্যাকআপ নিন। Online database, login, multi-device sync এবং পূর্ণ হিসাব যাচাই পরবর্তী ধাপে যুক্ত করতে হবে।

## লোকালি চালানো
```bash
npm install
npm run dev
```

## Android প্রজেক্ট তৈরি
```bash
npm install
npm run build
npx cap add android
npx cap sync android
```
এরপর Android Studio-তে `android` ফোল্ডার খুলে APK build করা যায়।

## GitHub-এ আপলোড
Repository-এর root-এ এই ফাইলগুলো যোগ করে commit/push করুন। `.env`, password বা secret key কখনো commit করবেন না।
