import React, { useEffect, useMemo, useState } from 'react';
import { LayoutDashboard, Users, ArrowLeftRight, Plus, Search, Wallet, TrendingUp, TrendingDown, Trash2, Download, BookOpen, X } from 'lucide-react';

const money = n => '৳' + Number(n || 0).toLocaleString('bn-BD');
const load = (key, fallback) => {
  try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; }
};

export default function App() {
  const [customers, setCustomers] = useState(() => load('tk3_customers', []));
  const [entries, setEntries] = useState(() => load('tk3_entries', []));
  const [tab, setTab] = useState('home');
  const [query, setQuery] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: '', phone: '', amount: '', type: 'due', note: '' });
  const [customerForm, setCustomerForm] = useState({ name: '', phone: '' });
  const [showCustomerForm, setShowCustomerForm] = useState(false);

  useEffect(() => localStorage.setItem('tk3_customers', JSON.stringify(customers)), [customers]);
  useEffect(() => localStorage.setItem('tk3_entries', JSON.stringify(entries)), [entries]);

  const totals = useMemo(() => entries.reduce((a, e) => {
    const amount = Number(e.amount) || 0;
    if (e.type === 'income') a.income += amount;
    if (e.type === 'expense') a.expense += amount;
    if (e.type === 'due') a.due += amount;
    if (e.type === 'paid') a.paid += amount;
    return a;
  }, { income: 0, expense: 0, due: 0, paid: 0 }), [entries]);

  const filteredCustomers = customers.filter(c => (c.name + ' ' + (c.phone || '')).toLowerCase().includes(query.toLowerCase()));

  function addEntry(e) {
    e.preventDefault();
    if (!form.name.trim() || Number(form.amount) <= 0) return;
    setEntries([{ ...form, id: crypto.randomUUID(), amount: Number(form.amount), date: new Date().toISOString() }, ...entries]);
    setForm({ name: '', phone: '', amount: '', type: 'due', note: '' });
    setShowForm(false);
  }
  function addCustomer(e) {
    e.preventDefault();
    if (!customerForm.name.trim()) return;
    setCustomers([{ ...customerForm, id: crypto.randomUUID() }, ...customers]);
    setCustomerForm({ name: '', phone: '' });
    setShowCustomerForm(false);
  }
  function exportData() {
    const blob = new Blob([JSON.stringify({ customers, entries }, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'tali-khata-backup.json'; a.click();
    URL.revokeObjectURL(url);
  }

  return <div className="app">
    <header className="topbar">
      <div className="brand-mark">TK</div>
      <div><div className="brand">টালি খাতা <span>V3</span></div><small>আপনার ব্যবসার হিসাব, সহজভাবে</small></div>
      <button className="icon-btn export" onClick={exportData} title="ডেটা ব্যাকআপ"><Download size={19}/></button>
    </header>

    <main>
      {tab === 'home' && <>
        <section className="welcome"><div><p>স্বাগতম</p><h1>আজকের হিসাব</h1><small>{new Date().toLocaleDateString('bn-BD', { dateStyle: 'full' })}</small></div><div className="welcome-icon"><BookOpen size={27}/></div></section>
        <section className="balance-card"><span>মোট বকেয়া</span><strong>{money(totals.due - totals.paid)}</strong><small>নথিভুক্ত লেনদেনের ভিত্তিতে</small></section>
        <div className="stat-grid">
          <div className="stat"><div className="stat-icon green"><TrendingUp size={18}/></div><small>মোট আয়</small><b>{money(totals.income)}</b></div>
          <div className="stat"><div className="stat-icon red"><TrendingDown size={18}/></div><small>মোট খরচ</small><b>{money(totals.expense)}</b></div>
          <div className="stat"><div className="stat-icon amber"><Wallet size={18}/></div><small>জমা পেয়েছেন</small><b>{money(totals.paid)}</b></div>
          <div className="stat"><div className="stat-icon blue"><Users size={18}/></div><small>কাস্টমার</small><b>{customers.length.toLocaleString('bn-BD')}</b></div>
        </div>
        <div className="section-head"><h2>সাম্প্রতিক লেনদেন</h2><button className="text-btn" onClick={() => setTab('transactions')}>সব দেখুন</button></div>
        <TransactionList entries={entries.slice(0, 5)} onDelete={id => setEntries(entries.filter(e => e.id !== id))}/>
        {!entries.length && <Empty text="এখনো কোনো লেনদেন যোগ করা হয়নি।" />}
      </>}

      {tab === 'customers' && <>
        <div className="page-title"><div><h1>কাস্টমার</h1><p>কাস্টমার তালিকা ও যোগাযোগ</p></div><button className="primary small" onClick={() => setShowCustomerForm(true)}><Plus size={17}/> যোগ করুন</button></div>
        <div className="search"><Search size={18}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="নাম বা ফোন দিয়ে খুঁজুন"/></div>
        <div className="customer-list">{filteredCustomers.map(c => <div className="customer" key={c.id}><div className="avatar">{c.name.slice(0,1)}</div><div className="customer-info"><b>{c.name}</b><small>{c.phone || 'ফোন নম্বর নেই'}</small></div><button className="icon-btn danger" onClick={() => setCustomers(customers.filter(x => x.id !== c.id))}><Trash2 size={17}/></button></div>)}</div>
        {!filteredCustomers.length && <Empty text="কোনো কাস্টমার পাওয়া যায়নি।"/>}
      </>}

      {tab === 'transactions' && <>
        <div className="page-title"><div><h1>লেনদেন</h1><p>আপনার সব হিসাব এক জায়গায়</p></div><button className="primary small" onClick={() => setShowForm(true)}><Plus size={17}/> যোগ করুন</button></div>
        <TransactionList entries={entries} onDelete={id => setEntries(entries.filter(e => e.id !== id))}/>
        {!entries.length && <Empty text="লেনদেন যোগ করলে এখানে দেখা যাবে।"/>}
      </>}
    </main>

    <button className="floating" onClick={() => tab === 'customers' ? setShowCustomerForm(true) : setShowForm(true)}><Plus size={23}/><span>{tab === 'customers' ? 'কাস্টমার' : 'লেনদেন'}</span></button>
    <nav className="bottom-nav">
      <button className={tab === 'home' ? 'active' : ''} onClick={() => setTab('home')}><LayoutDashboard/><span>হোম</span></button>
      <button className={tab === 'customers' ? 'active' : ''} onClick={() => setTab('customers')}><Users/><span>কাস্টমার</span></button>
      <button className={tab === 'transactions' ? 'active' : ''} onClick={() => setTab('transactions')}><ArrowLeftRight/><span>লেনদেন</span></button>
    </nav>

    {showForm && <Modal title="নতুন লেনদেন" onClose={() => setShowForm(false)}><form onSubmit={addEntry}>
      <label>নাম<input required value={form.name} onChange={e => setForm({...form, name:e.target.value})} placeholder="কাস্টমার/প্রতিষ্ঠানের নাম"/></label>
      <label>ফোন (ঐচ্ছিক)<input value={form.phone} onChange={e => setForm({...form, phone:e.target.value})} placeholder="01XXXXXXXXX"/></label>
      <label>টাকার পরিমাণ<input required type="number" min="1" value={form.amount} onChange={e => setForm({...form, amount:e.target.value})} placeholder="0"/></label>
      <label>লেনদেনের ধরন<select value={form.type} onChange={e => setForm({...form, type:e.target.value})}><option value="due">বাকি দিলাম</option><option value="paid">বাকি আদায়</option><option value="income">আয়</option><option value="expense">খরচ</option></select></label>
      <label>বিবরণ (ঐচ্ছিক)<input value={form.note} onChange={e => setForm({...form, note:e.target.value})} placeholder="লেনদেনের কারণ"/></label>
      <button className="primary submit" type="submit">সংরক্ষণ করুন</button>
    </form></Modal>}

    {showCustomerForm && <Modal title="নতুন কাস্টমার" onClose={() => setShowCustomerForm(false)}><form onSubmit={addCustomer}>
      <label>কাস্টমারের নাম<input required value={customerForm.name} onChange={e => setCustomerForm({...customerForm, name:e.target.value})} placeholder="নাম লিখুন"/></label>
      <label>ফোন নম্বর<input value={customerForm.phone} onChange={e => setCustomerForm({...customerForm, phone:e.target.value})} placeholder="01XXXXXXXXX"/></label>
      <button className="primary submit" type="submit">কাস্টমার সংরক্ষণ</button>
    </form></Modal>}
    <footer>টালি খাতা V3 · ডেটা এই ডিভাইসেই সংরক্ষিত থাকে</footer>
  </div>;
}

function TransactionList({ entries, onDelete }) {
  const labels = { due: 'বাকি', paid: 'বাকি আদায়', income: 'আয়', expense: 'খরচ' };
  return <div className="transactions">{entries.map(e => <div className="transaction" key={e.id}><div className={'tx-icon '+e.type}>{e.type === 'expense' ? <TrendingDown/> : e.type === 'income' ? <TrendingUp/> : <Wallet/>}</div><div className="tx-info"><b>{e.name}</b><small>{labels[e.type]} · {new Date(e.date).toLocaleDateString('bn-BD')}</small>{e.note && <small>{e.note}</small>}</div><div className="tx-amount"><b className={e.type === 'expense' || e.type === 'due' ? 'negative' : 'positive'}>{e.type === 'expense' || e.type === 'due' ? '−' : '+'}{money(e.amount)}</b><button className="delete" onClick={() => onDelete(e.id)} aria-label="মুছুন"><Trash2 size={14}/></button></div></div>)}</div>;
}
function Empty({ text }) { return <div className="empty"><Wallet size={28}/><p>{text}</p></div>; }
function Modal({ title, onClose, children }) { return <div className="overlay" onClick={onClose}><div className="modal" onClick={e => e.stopPropagation()}><div className="modal-head"><h2>{title}</h2><button className="icon-btn" onClick={onClose}><X/></button></div>{children}</div></div>; }